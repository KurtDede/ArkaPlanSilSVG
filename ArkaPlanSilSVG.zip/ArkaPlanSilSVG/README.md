# Arka Plan Sil → SVG

Android uygulaması: cihazdan görsel seçer, köşe/kenar renklerinden arka planı algılar, bağlantılı arka planı şeffaflaştırır ve sonucu SVG dosyası olarak kaydeder.

## Not
SVG çıktısı gerçek fotoğrafı Bézier/path vektörlerine çevirmek yerine şeffaf PNG sonucunu SVG kabı içine gömer. Bu yaklaşım fotoğraf kalitesini korur ve `.svg` dosyası verir.

## Derleme
Android Studio ile projeyi açın veya GitHub Actions'taki `Build APK` iş akışını çalıştırın. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.
