package com.oai.bg2svg;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.util.Base64;
import android.view.*;
import android.widget.*;

import java.io.*;
import java.util.ArrayDeque;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 10;
    private static final int SAVE_SVG = 11;
    private ImageView preview;
    private SeekBar tolerance;
    private TextView toleranceLabel, status;
    private Bitmap original, result;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        buildUi();
    }

    private TextView tv(String text, int sp, boolean bold) {
        TextView v = new TextView(this); v.setText(text); v.setTextSize(sp); v.setTextColor(Color.rgb(25,25,25));
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); return v;
    }
    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setTextAllCaps(false); b.setTextSize(16); b.setPadding(18,12,18,12); return b;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,28,28,36); root.setBackgroundColor(Color.WHITE);
        scroll.addView(root, new ScrollView.LayoutParams(-1,-2));
        TextView title = tv("Arka Plan Sil → SVG", 26, true); root.addView(title);
        TextView sub = tv("Görsel seç, arka planı temizle ve şeffaf sonucu SVG olarak kaydet.", 15, false); sub.setTextColor(Color.DKGRAY); sub.setPadding(0,8,0,18); root.addView(sub);
        Button pick = button("Görsel Seç"); root.addView(pick, new LinearLayout.LayoutParams(-1,-2));
        preview = new ImageView(this); preview.setScaleType(ImageView.ScaleType.FIT_CENTER); preview.setBackground(new ColorDrawable(Color.rgb(238,238,238)));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, dp(360)); ip.setMargins(0,18,0,12); root.addView(preview, ip);
        toleranceLabel = tv("Arka plan hassasiyeti: 48", 15, true); root.addView(toleranceLabel);
        tolerance = new SeekBar(this); tolerance.setMax(120); tolerance.setProgress(48); root.addView(tolerance, new LinearLayout.LayoutParams(-1,-2));
        TextView hint = tv("Düşük değer yalnızca fona çok benzeyen pikselleri, yüksek değer daha geniş renk aralığını temizler.", 13, false); hint.setTextColor(Color.GRAY); hint.setPadding(0,0,0,14); root.addView(hint);
        Button remove = button("Arka Planı Sil"); root.addView(remove, new LinearLayout.LayoutParams(-1,-2));
        Button save = button("SVG Olarak Kaydet"); LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2); sp.setMargins(0,10,0,0); root.addView(save, sp);
        status = tv("Hazır", 14, false); status.setPadding(0,14,0,0); status.setTextColor(Color.DKGRAY); root.addView(status);
        pick.setOnClickListener(v -> pickImage());
        remove.setOnClickListener(v -> process());
        save.setOnClickListener(v -> saveSvg());
        tolerance.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int p,boolean f){ toleranceLabel.setText("Arka plan hassasiyeti: "+p); } public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} });
        setContentView(scroll);
    }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private void pickImage(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); startActivityForResult(i,PICK_IMAGE); }
    @Override protected void onActivityResult(int r,int c,Intent data){ super.onActivityResult(r,c,data); if(c!=RESULT_OK||data==null)return; try{
        if(r==PICK_IMAGE){ Uri u=data.getData(); InputStream in=getContentResolver().openInputStream(u); Bitmap b=BitmapFactory.decodeStream(in); if(in!=null)in.close();
            if(b==null) throw new IOException("Görsel açılamadı"); original=limitSize(b,1600); result=null; preview.setImageBitmap(original); status.setText("Görsel yüklendi: "+original.getWidth()+"×"+original.getHeight()); }
        else if(r==SAVE_SVG){ Uri u=data.getData(); writeSvg(u); }
    }catch(Exception e){ toast("Hata: "+e.getMessage()); }}
    private Bitmap limitSize(Bitmap b,int max){ int w=b.getWidth(),h=b.getHeight(); if(Math.max(w,h)<=max)return b.copy(Bitmap.Config.ARGB_8888,true); float s=max/(float)Math.max(w,h); return Bitmap.createScaledBitmap(b,Math.round(w*s),Math.round(h*s),true).copy(Bitmap.Config.ARGB_8888,true); }
    private void process(){ if(original==null){toast("Önce bir görsel seç.");return;} status.setText("Arka plan işleniyor…"); final int tol=tolerance.getProgress();
        new Thread(() -> { Bitmap out=removeBackground(original,tol); runOnUiThread(() -> {result=out;preview.setImageBitmap(result);status.setText("Arka plan temizlendi. SVG olarak kaydedebilirsin.");}); }).start(); }
    private Bitmap removeBackground(Bitmap src,int tol){ int w=src.getWidth(),h=src.getHeight(); int[] px=new int[w*h]; src.getPixels(px,0,w,0,0,w,h);
        int bg=averageCorners(px,w,h); boolean[] seen=new boolean[px.length]; ArrayDeque<Integer> q=new ArrayDeque<>();
        for(int x=0;x<w;x++){ q.add(x); q.add((h-1)*w+x);} for(int y=1;y<h-1;y++){q.add(y*w);q.add(y*w+w-1);} int t2=tol*tol*3;
        while(!q.isEmpty()){ int i=q.removeFirst(); if(i<0||i>=px.length||seen[i])continue; seen[i]=true; int c=px[i]; if(colorDist2(c,bg)>t2)continue; px[i]=c & 0x00FFFFFF; int x=i%w,y=i/w; if(x>0)q.add(i-1); if(x<w-1)q.add(i+1); if(y>0)q.add(i-w); if(y<h-1)q.add(i+w); }
        // edge feather: soften opaque pixels touching transparent background
        int[] copy=px.clone(); for(int y=1;y<h-1;y++)for(int x=1;x<w-1;x++){int i=y*w+x; if((copy[i]>>>24)==0)continue; int trans=0; for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++)if((copy[(y+dy)*w+x+dx]>>>24)==0)trans++; if(trans>0&&trans<9){int a=Math.max(70,255-trans*24); px[i]=(a<<24)|(copy[i]&0x00FFFFFF);} }
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); out.setPixels(px,0,w,0,0,w,h); return out; }
    private int averageCorners(int[] p,int w,int h){ int r=0,g=0,b=0,n=0,sw=Math.max(2,Math.min(w,h)/18); int[][] starts={{0,0},{w-sw,0},{0,h-sw},{w-sw,h-sw}}; for(int[] s:starts)for(int y=s[1];y<Math.min(h,s[1]+sw);y+=2)for(int x=s[0];x<Math.min(w,s[0]+sw);x+=2){int c=p[y*w+x];r+=(c>>16)&255;g+=(c>>8)&255;b+=c&255;n++;} return Color.rgb(r/n,g/n,b/n); }
    private int colorDist2(int a,int b){int dr=((a>>16)&255)-((b>>16)&255), dg=((a>>8)&255)-((b>>8)&255), db=(a&255)-(b&255); return dr*dr+dg*dg+db*db;}
    private void saveSvg(){ if(result==null){toast("Önce arka planı sil.");return;} Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/svg+xml"); i.putExtra(Intent.EXTRA_TITLE,"arkaplan_silinmis.svg"); startActivityForResult(i,SAVE_SVG); }
    private void writeSvg(Uri uri)throws Exception{ ByteArrayOutputStream bos=new ByteArrayOutputStream(); result.compress(Bitmap.CompressFormat.PNG,100,bos); String b64=Base64.encodeToString(bos.toByteArray(),Base64.NO_WRAP); String svg="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"+
            "<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\""+result.getWidth()+"\" height=\""+result.getHeight()+"\" viewBox=\"0 0 "+result.getWidth()+" "+result.getHeight()+"\">\n"+
            "<image width=\"100%\" height=\"100%\" xlink:href=\"data:image/png;base64,"+b64+"\"/>\n</svg>"; OutputStream out=getContentResolver().openOutputStream(uri,"wt"); out.write(svg.getBytes("UTF-8")); out.close(); status.setText("SVG kaydedildi."); toast("SVG kaydedildi"); }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
